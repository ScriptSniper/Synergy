pwd
ls -la
mkdir build 
cd build
cmake ..
make