---
name: Feature request
about: Suggest an idea for this project
title: Make beep sound when moving from client to server
labels: enhancement, triage
assignees: ''

---

### Problem ###

[A clear and concise description of what the problem is. ]

### Solution ###

[A clear and concise description of what you want to happen.]

### More Info ###

- Describe alternatives you've considered
- Add any other context or screenshots about the feature request here
